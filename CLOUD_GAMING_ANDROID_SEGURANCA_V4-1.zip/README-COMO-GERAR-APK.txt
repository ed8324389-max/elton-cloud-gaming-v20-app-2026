CLOUD GAMING — Projeto Android

O workflow em .github/workflows/build-apk.yml gera um APK de teste (debug) pelo GitHub Actions.

CONFIGURAÇÃO
- Java 17
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- compileSdk 36 / targetSdk 36
- Nome visível do app: CLOUD GAMING

GERAR APK
1. Envie o conteúdo deste projeto para a raiz do repositório GitHub.
2. Abra Actions > Build APK > Run workflow (ou envie um commit na branch main).
3. Quando terminar, abra a execução concluída e baixe o artefato CLOUD-GAMING-APK.
4. Extraia o artefato para obter app-debug.apk.

IMPORTANTE
- Este artefato de debug serve para teste, não é o pacote assinado de produção para a Play Store.
- Ainda é necessário compilar, instalar e testar o APK em um Android real.
- A publicação da IA exige site publicado no Netlify e variável OPENAI_API_KEY configurada em ambiente seguro. Não coloque essa chave no HTML ou no APK.
- A tela de IA dentro do APK local precisa de uma URL pública de backend configurada; o caminho relativo do Netlify não funciona automaticamente em file:///android_asset.
- Antes da publicação, confirme a política de privacidade, classificação de conteúdo, ficha da loja, assinatura e requisitos da conta Play Console.
