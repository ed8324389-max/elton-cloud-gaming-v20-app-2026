ELTON CLOUD GAMING V20 — PROJETO ANDROID PARA GERAR APK

O QUE ESTE ZIP CONTEM
- Aplicativo Android simples que abre a versão V20 incluída em app/src/main/assets/index.html.
- Ícone do aplicativo.
- Links externos encaminhados ao navegador/Google Play quando tocados.
- Workflow do GitHub Actions para compilar o APK de teste.

IMPORTANTE
Este ZIP ainda NÃO é o APK. O APK precisa ser compilado pelo GitHub Actions ou em um computador com Android SDK. Não foi possível executar a compilação neste ambiente porque o Android SDK/Gradle não estão instalados aqui.

COMO GERAR PELO CELULAR ANDROID
1. Entre em https://github.com e faça login. Não compartilhe sua senha com ninguém.
2. Crie um repositório novo, por exemplo: elton-cloud-gaming-android. Para simplificar, pode marcar como Public.
3. Envie os arquivos e pastas DENTRO deste ZIP para a raiz do repositório (não envie o ZIP como único arquivo). Preserve a pasta .github/workflows. Se a pasta .github não aparecer no seletor de upload do celular, será necessário usar o site em modo para computador ou enviar os arquivos por outro método.
4. Abra a aba Actions do repositório e selecione “Build APK”.
5. Toque em “Run workflow” e confirme.
6. Aguarde o trabalho ficar verde (Success). Abra a execução concluída e baixe o artefato ELTON-CLOUD-GAMING-V20-APK.
7. Extraia o ZIP do artefato, toque em app-debug.apk e permita instalação desta fonte se o Android pedir. Instale apenas o APK gerado no seu próprio repositório.

TESTE
- Abra o app e confirme que a tela inicial carrega.
- Teste imagens (precisam de internet), busca e alguns links do catálogo.
- Este APK é de teste/debug e não está assinado para lançamento na Play Store.

OBSERVACOES
- O catálogo usa imagens e links de serviços externos, então esses itens precisam de conexão com internet.
- Esta compilação empacota a cópia local do site V20; mudanças futuras no site online não atualizam automaticamente esta cópia do APK. Para isso seria necessário alterar o app para carregar a URL pública do Netlify.
