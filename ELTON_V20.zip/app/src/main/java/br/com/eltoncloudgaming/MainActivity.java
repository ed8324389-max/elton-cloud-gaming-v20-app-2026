package br.com.eltoncloudgaming;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  private WebView webView;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(16,16,24));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,16,24));

    webView = new WebView(this);
    webView.setBackgroundColor(android.graphics.Color.rgb(16,16,24));
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setLoadsImagesAutomatically(true);
    settings.setMediaPlaybackRequiresUserGesture(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(true);
    settings.setSupportZoom(false);
    webView.setWebChromeClient(new WebChromeClient());
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return openExternalIfNeeded(request.getUrl());
      }
      @SuppressWarnings("deprecation")
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return openExternalIfNeeded(Uri.parse(url));
      }
    });
    setContentView(webView);
    if (savedInstanceState == null) {
      webView.loadUrl("file:///android_asset/index.html");
    } else {
      webView.restoreState(savedInstanceState);
    }
  }

  private boolean openExternalIfNeeded(Uri uri) {
    String scheme = uri.getScheme();
    if (scheme == null || "file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) return false;
    if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "market".equalsIgnoreCase(scheme)) {
      try {
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
      } catch (ActivityNotFoundException ignored) {
        if ("market".equalsIgnoreCase(scheme)) {
          try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store"))); }
          catch (ActivityNotFoundException ignoredAgain) { }
        }
      }
      return true;
    }
    return true;
  }

  @Override protected void onSaveInstanceState(Bundle outState) {
    super.onSaveInstanceState(outState);
    if (webView != null) webView.saveState(outState);
  }

  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }
}
