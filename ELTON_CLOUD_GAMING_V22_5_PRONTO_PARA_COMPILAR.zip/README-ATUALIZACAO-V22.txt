CLOUD GAMING V22 — atualização Android

Alterações: catálogo HTML ampliado; visual preto e verde; ícones Android substituídos; versionCode 22; workflow de compilação APK.

Para gerar APK: envie o conteúdo deste ZIP ao repositório GitHub (substituindo os arquivos correspondentes), abra Actions e execute Build CLOUD GAMING APK. Baixe o artefato CLOUD-GAMING-V22-APK.

VERSAO 22.3
- Ajuste de metadados Android: versionCode 23 e versionName 22.3.
- Revisao estatica: 8 blocos JavaScript passaram em node --check; 369 botoes HTML identificados; IDs HTML sem duplicidade.
- O APK ainda precisa ser compilado pelo GitHub Actions e testado em aparelho Android. A revisao estatica nao comprova funcionamento de cada botao nem disponibilidade de links externos.
