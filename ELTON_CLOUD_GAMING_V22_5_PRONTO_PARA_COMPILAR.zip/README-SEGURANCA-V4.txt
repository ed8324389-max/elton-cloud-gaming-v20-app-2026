CLOUD GAMING — REVISÃO DE SEGURANÇA (V4)

Mudanças aplicadas no pacote:
- Função de IA valida método, tamanho do corpo, mensagens e tamanho por mensagem.
- Limite de uso best-effort por instância e respostas de erro genéricas. Para limite global confiável, configure um serviço de rate limiting compartilhado.
- A chave OPENAI_API_KEY continua exclusivamente no ambiente seguro do Netlify.
- CORS pode ser restrito por ALLOWED_ORIGINS (lista de origens separadas por vírgula). Configure a URL pública exata do site.
- Adicionada página privacy.html e link na interface.
- Cabeçalhos básicos de segurança e cache da política.
- Atualizado cache do service worker.

CONFIGURAÇÃO OBRIGATÓRIA NO NETLIFY
1. Configure OPENAI_API_KEY em Site configuration > Environment variables.
2. Configure ALLOWED_ORIGINS com a origem do site publicado, por exemplo https://SEU-SITE.netlify.app (substitua pelo domínio real).
3. Faça novo deploy e teste a IA, respostas 429, método inválido e falha quando a chave estiver ausente.
4. Confirme as configurações reais de logs/retenção do Netlify e do provedor de IA.

IMPORTANTE
- O limite por IP dentro da função é best-effort e não é um limite global entre instâncias serverless. Use rate limiting compartilhado para produção com tráfego real.
- A política de privacidade é um rascunho operacional: o responsável deve confirmar os serviços e práticas efetivamente ativos e adicionar/confirmar um contato público funcional antes da publicação.
- Segurança dos dados do Google Play precisa ser preenchida conforme o comportamento real, incluindo dados enviados ao provedor de IA.
- Não foi possível executar teste real no dispositivo nem confirmar deploy público a partir deste pacote. A revisão estática não equivale a auditoria independente nem garante aprovação na Play Store.
- APK local usa file:///android_asset/index.html; a rota relativa /.netlify/functions/chat não funciona automaticamente no APK. Não declare a IA no APK como funcional até conectar e testar um endpoint HTTPS público.
